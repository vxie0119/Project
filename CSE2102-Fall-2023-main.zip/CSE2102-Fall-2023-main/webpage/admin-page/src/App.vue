<template>
  <Admin msg="Welcome to Your Vue.js App"/>
</template>

<script>
import Admin from './components/HelloWorld.vue'

export default {
  name: 'App',
  components: {
    Admin
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: white;
}
body {
  background: #000
  
}
</style>

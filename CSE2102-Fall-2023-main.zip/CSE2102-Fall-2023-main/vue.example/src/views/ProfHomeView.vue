<template>
    <main class="ProfHome">
        <header>Welcome Professor!</header>
        <body></body>
    </main>
</template>

<style>
.ProfHome {
    height: 100%;
    background-color: white;
}

.ProfHome header {
    display: grid;
    align-items: center;
    justify-items: center;
    font-size: larger;
    padding-top: 25px;
}

.ProfHome body {
    background: white;
}
</style>
